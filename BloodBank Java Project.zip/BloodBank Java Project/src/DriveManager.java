import java.sql.Connection;

public class DriveManager {

	public static Connection getConnection(String string, String string2, String string3) {
		// TODO Auto-generated method stub
		return null;
	}

}
